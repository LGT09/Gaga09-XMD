require('dotenv').config();

module.exports = {
  OWNER_NUMBER: process.env.OWNER_NUMBER,
  OPENAI_KEY: process.env.OPENAI_KEY,
};